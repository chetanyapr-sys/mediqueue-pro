"use client"

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { UserButton } from "@clerk/nextjs";
import { LayoutDashboard, Search, History, UserCircle, Settings, Stethoscope, ChevronLeft, ChevronRight } from "lucide-react";

const NAV_ITEMS = [
  { href: "/dashboard/patient", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/dashboard/patient/find-doctors", label: "Find Doctors", icon: Search, exact: false },
  { href: "/dashboard/patient/history", label: "History", icon: History, exact: false },
  { href: "/dashboard/patient/profile", label: "Profile", icon: UserCircle, exact: false },
  { href: "/dashboard/patient/settings", label: "Settings", icon: Settings, exact: false },
];

export default function PatientSidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={`sticky top-0 h-screen shrink-0 bg-zinc-950 border-r border-zinc-900 flex flex-col transition-all duration-300 ${
        collapsed ? "w-[76px]" : "w-64"
      }`}
    >
      <div className={`flex items-center gap-2.5 px-5 h-16 border-b border-zinc-900 ${collapsed ? "justify-center px-0" : ""}`}>
        <div className="h-8 w-8 rounded-xl bg-blue-600 flex items-center justify-center shrink-0">
          <Stethoscope className="h-4 w-4 text-white" />
        </div>
        {!collapsed && (
          <span className="text-white font-black tracking-tight text-sm truncate">
            MediQueue <span className="text-zinc-600 font-medium italic">Pro</span>
          </span>
        )}
      </div>

      <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = item.exact ? pathname === item.href : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              title={collapsed ? item.label : undefined}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all duration-300 ${
                isActive
                  ? "bg-white text-black"
                  : "text-zinc-500 hover:text-white hover:bg-zinc-900"
              } ${collapsed ? "justify-center" : ""}`}
            >
              <item.icon className="h-4 w-4 shrink-0" />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={() => setCollapsed((c) => !c)}
        suppressHydrationWarning
        className="mx-3 mb-3 flex items-center justify-center gap-2 py-2 rounded-xl text-zinc-600 hover:text-white hover:bg-zinc-900 transition-all text-[10px] font-black uppercase tracking-widest"
      >
        {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <><ChevronLeft className="h-3.5 w-3.5" /> Collapse</>}
      </button>

      <div className={`flex items-center gap-2.5 px-4 py-4 border-t border-zinc-900 ${collapsed ? "justify-center px-0" : ""}`}>
        <UserButton appearance={{ elements: { avatarBox: "h-8 w-8" } }} />
        {!collapsed && (
          <span className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Account</span>
        )}
      </div>
    </aside>
  );
}