import { db } from "@/lib/db";
import { currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { User, Calendar, Clock, CheckCircle, ArrowRight } from "lucide-react";
import { callNextPatient, completeAppointment, cancelAppointment } from "@/actions/appointment";
import { toggleAvailability } from "@/actions/doctor";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function DoctorDashboard() {
  const user = await currentUser();
  if (!user) redirect("/");

  const doctor = await db.doctor.findUnique({
    where: { userId: user.id },
    include: { user: true }
  });

  if (!doctor) redirect("/dashboard/doctor/onboarding");

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayEnd = new Date(todayStart);
  todayEnd.setDate(todayEnd.getDate() + 1);

  const [totalPatients, todayAppts, inQueue, completed] = await Promise.all([
    db.appointment.count({ where: { doctorId: user.id } }),
    db.appointment.count({ where: { doctorId: user.id, appointmentDate: { gte: todayStart, lt: todayEnd } } }),
    db.appointment.count({ where: { doctorId: user.id, status: "WAITING", appointmentDate: { gte: todayStart, lt: todayEnd } } }),
    db.appointment.count({ where: { doctorId: user.id, status: "COMPLETED" } }),
  ]);

  const recentAppointments = await db.appointment.findMany({
    where: { doctorId: user.id, appointmentDate: { gte: todayStart, lt: todayEnd } },
    orderBy: { appointmentDate: "asc" },
    take: 4,
    include: { patient: true }
  });

  const nowServing = await db.appointment.findFirst({
    where: { doctorId: user.id, status: "IN_PROGRESS", appointmentDate: { gte: todayStart, lt: todayEnd } },
    include: { patient: true }
  });

  const stats = [
    { title: "Total Patients", value: totalPatients, icon: User, color: "text-blue-500" },
    { title: "Today's Appointments", value: todayAppts, icon: Calendar, color: "text-purple-500" },
    { title: "In Queue", value: inQueue, icon: Clock, color: "text-orange-500" },
    { title: "Completed", value: completed, icon: CheckCircle, color: "text-emerald-500" },
  ];

  return (
    <div className="p-6 md:p-8 bg-black min-h-screen text-white space-y-8 max-w-6xl mx-auto">
      <div className="flex flex-wrap justify-between items-end gap-4">
        <div>
          <h1 className="text-4xl font-black tracking-tighter uppercase">Doctor <span className="text-zinc-600 italic">Dashboard</span></h1>
          <p className="text-zinc-500 font-bold italic">Hospital Flow: Dr. {doctor.user.name}</p>
        </div>
        <form action={toggleAvailability.bind(null, user.id, doctor.isAvailable)}>
          <button
            type="submit"
            title="Click to toggle your availability"
            suppressHydrationWarning
            className={`px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 ${
              doctor.isAvailable
                ? "bg-emerald-500/10 border border-emerald-500/20 hover:bg-emerald-500/20"
                : "bg-red-500/10 border border-red-500/20 hover:bg-red-500/20"
            }`}
          >
            <div className={`h-2 w-2 rounded-full animate-pulse ${doctor.isAvailable ? "bg-emerald-500" : "bg-red-500"}`} />
            <span className={`text-[10px] font-black uppercase tracking-widest ${doctor.isAvailable ? "text-emerald-500" : "text-red-500"}`}>
              {doctor.isAvailable ? "Available — Tap to go Offline" : "Offline — Tap to go Online"}
            </span>
          </button>
        </form>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div
            key={s.title}
            className="group bg-zinc-900/40 border border-zinc-800 p-6 rounded-[2rem] space-y-3 transition-all duration-300 hover:border-zinc-600 hover:bg-zinc-900/70 hover:-translate-y-1 hover:shadow-xl hover:shadow-black/40"
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-black uppercase tracking-widest text-zinc-600">{s.title}</span>
              <s.icon className={`h-5 w-5 ${s.color} transition-transform duration-300 group-hover:scale-125`} />
            </div>
            <div className="text-4xl font-black italic">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-zinc-900/20 border border-zinc-800 rounded-[2.25rem] p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-black italic uppercase">Today's Appointments</h3>
            <Link href="/dashboard/doctor/appointments" className="flex items-center gap-1 text-[10px] font-black uppercase text-zinc-500 hover:text-white transition-colors">
              View All <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="space-y-3">
            {recentAppointments.map((appt) => (
              <Link
                key={appt.id}
                href={`/dashboard/doctor/appointments/${appt.id}`}
                className="flex items-center justify-between p-4 bg-zinc-900/50 rounded-2xl border border-zinc-800/50 transition-all duration-300 hover:bg-zinc-800/60 hover:border-zinc-700"
              >
                <div className="flex items-center gap-3">
                  <div className="h-11 w-11 bg-zinc-800 rounded-xl flex items-center justify-center font-bold text-blue-500 shrink-0">
                    #{appt.tokenNumber}
                  </div>
                  <div>
                    <p className="font-black uppercase text-sm">{appt.patient?.name || "Patient"}</p>
                    <p className="text-[10px] text-zinc-500 font-bold uppercase">{appt.status}</p>
                  </div>
                </div>
                <div className="text-[10px] font-black text-zinc-700">
                  {new Date(appt.appointmentDate).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                </div>
              </Link>
            ))}
            {recentAppointments.length === 0 && (
              <p className="text-zinc-600 italic text-center py-10">No appointments today.</p>
            )}
          </div>
        </div>

        <div className="bg-zinc-900/20 border border-zinc-800 rounded-[2.25rem] p-6 flex flex-col justify-center items-center space-y-3">
           <h3 className="text-lg font-black italic uppercase text-zinc-500">Live Queue</h3>

           {nowServing ? (
             <>
               <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Now Serving</span>
               <div className="text-6xl font-black italic leading-none text-white tracking-tighter">
                 #{nowServing.tokenNumber}
               </div>
               <p className="font-black uppercase text-sm text-zinc-300">{nowServing.patient?.name || "Patient"}</p>
               <div className="flex items-center gap-3 w-full pt-1">
                 <form action={completeAppointment.bind(null, nowServing.id)} className="flex-1">
                   <button
                     type="submit"
                     suppressHydrationWarning
                     className="w-full px-6 py-3.5 bg-emerald-500 text-black font-black uppercase tracking-widest rounded-2xl hover:bg-emerald-400 transition-all duration-300 hover:-translate-y-0.5 text-sm"
                   >
                     Mark as Completed
                   </button>
                 </form>
                 <form action={cancelAppointment.bind(null, nowServing.id)} className="flex-1">
                   <button
                     type="submit"
                     title="Cancel this appointment"
                     suppressHydrationWarning
                     className="w-full px-6 py-3.5 bg-zinc-900 border border-zinc-800 text-zinc-400 font-black uppercase tracking-widest rounded-2xl hover:bg-red-500/10 hover:text-red-500 hover:border-red-500/30 transition-all duration-300 text-sm"
                   >
                     Cancel
                   </button>
                 </form>
               </div>
             </>
           ) : (
             <>
               <div className="text-7xl font-black italic leading-none text-white tracking-tighter">
                 {String(inQueue).padStart(2, '0')}
               </div>
               <form action={callNextPatient.bind(null, user.id)}>
                 <button
                   type="submit"
                   disabled={inQueue === 0}
                   suppressHydrationWarning
                   className="px-8 py-3.5 bg-white text-black font-black uppercase tracking-widest rounded-2xl hover:bg-blue-600 hover:text-white transition-all duration-300 hover:-translate-y-0.5 disabled:opacity-30 disabled:pointer-events-none"
                 >
                   Call Next Patient
                 </button>
               </form>
             </>
           )}
        </div>
      </div>
    </div>
  );
}